!Disclamer!
By building the below D.I.Y electrical assembly you (the builder and/or end user) assume all responsibility for evaluating the safety and use.
I do not make any claim of durability, safety or proper use.  I, the creator of the parts list and .stl files am
not responsible for any property damage or personal harm resulting from the assembly and use of this D.I.Y electrical assembly.

This assembly requires the builder to use the resorces contained in this zip folder as well as the 
instructions and pinned posts from DIY and other channels in the SlimeVR Discord server.

Note on charging
- Please use a wall adapter rated at 750ma or lower for charging
- If a wall adapter rated at greater than 750ma is used, please do not leave unattended
while charging and monitor temperature.

Print list for 8 track points:
2x Slime basic shell
3x Slime basic shell with aux
3x Aux clamp
5x Slime basic divider
3x Slime basic cover with logo
2x Slime basic cover with logo inverted
1x chest base
2x foot base
3x chest-foot cap

*note, I recommend to print in the orientation they load. 20% infill, 3 Walls, w/supports, brim if necessary


Amazon parts list in included picture and links down below

Addtional parts needed:
8X BNO08X
15"*ish of larger gauge wire (I used 20ga) to connect batteries to the charge boards (if your battery's leads are too short)

Additional notes for assembly:
- Reference included pictures for board orientations
- make sure the orientation of the BNO08X is the same as the main and the aux!
- Remove existing wires and connector from the battery and use other wire to go up to the charge board if your batteries wire does not reach
- keep the area in the center of the each of the boards clear of wiring, to aviod the hold down pillars on the cover or the cover will not close

Notes for firmware edits
- Waist and legs IMU_ROTATION 0 (usb's point down)
- Ankles IMU_ROTATION PI (usb's point up)



Links:
https://www.amazon.com/dp/B06ZZL5JZY/?coliid=I3O67MQKJK4UL0&colid=T9QAPPRFDJBW&psc=1&ref_=lv_ov_lig_dp_it
https://www.amazon.com/dp/B089SH7XYB/?coliid=I3SBQ76MVEKMIW&colid=T9QAPPRFDJBW&psc=1&ref_=lv_ov_lig_dp_it
https://www.amazon.com/dp/B07DCRVQ5Z/?coliid=I15UOUR5LVCPP3&colid=T9QAPPRFDJBW&psc=1&ref_=lv_ov_lig_dp_it
https://www.amazon.com/dp/B088F73158/?coliid=I1SI2S5PHYER0C&colid=T9QAPPRFDJBW&psc=1&ref_=lv_ov_lig_dp_it
https://www.amazon.com/dp/B07HZ8TQTK/?coliid=I31UWWRF5017JM&colid=T9QAPPRFDJBW&psc=1&ref_=lv_ov_lig_dp_it
https://www.amazon.com/dp/B0876NGF9Z/?coliid=I255WOES00Y4NZ&colid=T9QAPPRFDJBW&psc=1&ref_=lv_ov_lig_dp_it
https://www.amazon.com/dp/B08HGJK1ZC/?coliid=I30V8Y75KXB67R&colid=T9QAPPRFDJBW&psc=1&ref_=lv_ov_lig_dp_it
https://www.amazon.com/dp/B07TS8N6JK/?coliid=IHAZ2MOJPLZ22&colid=T9QAPPRFDJBW&psc=1&ref_=lv_ov_lig_dp_it
https://www.amazon.com/dp/B08ZY7Q7TW/?coliid=I1X8L55H37KNF1&colid=T9QAPPRFDJBW&psc=1&ref_=lv_ov_lig_dp_it



